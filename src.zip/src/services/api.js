import { supabase } from "./supabaseClient";

export const attendanceService = {
  saveAttendance: async (records) => {
    const { data, error } = await supabase
      .from("study_attendance")
      .insert(records)
      .select();

    if (error) throw error;
    return data;
  },

  getAttendanceHistory: async (groupId) => {
    const { data, error } = await supabase
      .from("study_attendance")
      .select(`
        *,
        members(full_name, image_url)
      `)
      .eq("group_id", groupId)
      .order("date", { ascending: false });
    
    if (error) throw error;
    return data;
  },

  getAllAttendance: async () => {
    const { data, error } = await supabase
      .from("study_attendance")
      .select(`
        *,
        members(full_name, image_url),
        bible_study_groups(group_name)
      `)
      .order("date", { ascending: false });
    
    if (error) throw error;
    return data;
  }
};

export const studyService = {
  saveStudy: async (study) => {
    const { data, error } = await supabase
      .from("study_progress")
      .insert([study])
      .select();

    if (error) throw error;
    return data;
  },

  getStudyHistory: async (groupId) => {
    const { data, error } = await supabase
      .from("study_progress")
      .select("*")
      .eq("group_id", groupId)
      .order("completion_date", { ascending: false });
    
    if (error) throw error;
    return data;
  },

  getAllStudyProgress: async () => {
    const { data, error } = await supabase
      .from("study_progress")
      .select(`
        *,
        bible_study_groups(group_name)
      `)
      .order("completion_date", { ascending: false });
    
    if (error) throw error;
    return data;
  }
};

export const financeService = {
  createTransaction: async (data) => {
    const { data: transData, error } = await supabase.from("transactions").insert([data]).select();
    if (error) throw error;
    return transData;
  },

  getTransactions: async () => {
    const { data, error } = await supabase
      .from("transactions")
      .select(`
        *,
        members(full_name, image_url),
        profiles(full_name)
      `)
      .order("transaction_date", { ascending: false });
    if (error) throw error;
    return data;
  },

  getBudgets: async () => {
    const { data, error } = await supabase
      .from("budgets")
      .select(`
        *,
        approvals(*)
      `)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data;
  },

  approveBudget: async (requestId, approver, status, role, comment) => {
    // 1. Record approval
    const { error: approvalError } = await supabase.from('approvals').insert({
      request_id: requestId,
      approver_id: approver.id,
      approver_name: approver.full_name,
      role,
      status,
      comment
    });
    if (approvalError) throw approvalError;

    // 2. Log activity
    await supabase.from('activity_logs').insert({
      user_id: approver.id,
      action: status === 'approved' ? 'approve' : 'reject',
      description: `${approver.full_name} ${status === 'approved' ? 'approved' : 'rejected'} budget as ${role}`,
      entity_type: 'budget',
      entity_id: requestId
    });

    // 3. Update budget status
    let newStatus;
    if (status === 'rejected') {
      newStatus = 'Rejected';
    } else {
      // If signer approved, it's fully approved regardless of current status
      // If justifier approved and it was Pending, it's partially approved
      newStatus = role === 'signer' ? 'Approved' : 'Partially Approved';
    }
    
    const { data, error: budgetError } = await supabase
      .from('budgets')
      .update({ status: newStatus })
      .eq('id', requestId)
      .select();
      
    if (budgetError) throw budgetError;
    return data;
  },

  getApprovedBudgets: async () => {
    const { data, error } = await supabase
      .from("budgets")
      .select(`
        *,
        approvals(*)
      `)
      .eq("status", "Approved")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data;
  },

  createBudget: async (budget) => {
    const { data, error } = await supabase
      .from("budgets")
      .insert([{ ...budget, status: "Pending" }])
      .select();
    if (error) throw error;
    return data;
  },

  updateBudgetStatus: async (id, status) => {
    const { data, error } = await supabase
      .from("budgets")
      .update({ status })
      .eq("id", id)
      .select();
    if (error) throw error;
    return data;
  },

  updateBudgetUsage: async (id, is_used) => {
    const { data, error } = await supabase
      .from("budgets")
      .update({ is_used })
      .eq("id", id)
      .select();
    if (error) throw error;
    return data;
  }
};

export const memberService = {
  getMembers: async () => {
    const { data, error } = await supabase.from("members").select(`
      *,
      bible_study_groups(group_name)
    `).order("full_name");
    if (error) throw error;
    return data;
  },
  createMember: async (member) => {
    const { data, error } = await supabase.from("members").insert([member]).select();
    if (error) throw error;
    return data;
  },
  updateMember: async (id, member) => {
    const { data, error } = await supabase.from("members").update(member).eq("id", id).select();
    if (error) throw error;
    return data;
  },
  deleteMember: async (id) => {
    const { error } = await supabase.from("members").delete().eq("id", id);
    if (error) throw error;
    return true;
  }
};

export const groupService = {
  getGroups: async () => {
    const { data, error } = await supabase.from("bible_study_groups").select(`
      *,
      group_leaders(
        profiles(full_name, role)
      ),
      members(id)
    `).order("group_name");
    
    if (error) throw error;
    
    // Flatten data for easier consumption in frontend
    return data.map(g => ({
      ...g,
      leaders: g.group_leaders?.map(gl => gl.profiles) || [],
      members_count: g.members?.length || 0
    }));
  },

  assignLeader: async (groupId, userId) => {
    const { data, error } = await supabase
      .from("group_leaders")
      .insert({ group_id: groupId, user_id: userId })
      .select();
    
    if (error) throw error;
    return data;
  },

  createGroup: async (group) => {
    const { data, error } = await supabase.from("bible_study_groups").insert([group]).select();
    if (error) throw error;
    return data;
  },

  deleteGroup: async (id) => {
    const { error } = await supabase.from("bible_study_groups").delete().eq("id", id);
    if (error) throw error;
    return true;
  }
};

export const eventService = {
  getEvents: async () => {
    const { data, error } = await supabase.from("events").select("*").order("date", { ascending: false });
    if (error) throw error;
    return data;
  },
  createEvent: async (event) => {
    const { data, error } = await supabase.from("events").insert([event]).select();
    if (error) throw error;
    return data;
  },
  updateEvent: async (id, updates) => {
    const { data, error } = await supabase.from("events").update(updates).eq("id", id).select();
    if (error) throw error;
    return data;
  },
  deleteEvent: async (id) => {
    const { error } = await supabase.from("events").delete().eq("id", id);
    if (error) throw error;
  }
};

export const activityService = {
  getActivities: async (groupId = null) => {
    // Fetch attendance records
    let attendanceQuery = supabase
      .from("study_attendance")
      .select(`
        id, date, created_at, group_id,
        members(full_name, image_url),
        bible_study_groups(group_name)
      `)
      .order("created_at", { ascending: false })
      .limit(50);

    if (groupId) {
      attendanceQuery = attendanceQuery.eq("group_id", groupId);
    }

    const { data: attendanceData, error: attendanceError } = await attendanceQuery;
    if (attendanceError) throw attendanceError;

    // Fetch study progress records
    let studyQuery = supabase
      .from("study_progress")
      .select(`
        id, study_topic, completion_date, created_at, group_id,
        bible_study_groups(group_name)
      `)
      .order("created_at", { ascending: false })
      .limit(50);

    if (groupId) {
      studyQuery = studyQuery.eq("group_id", groupId);
    }

    const { data: studyData, error: studyError } = await studyQuery;
    if (studyError) throw studyError;

    // Combine and sort both feeds
    const combined = [
      ...(attendanceData || []).map(a => ({
        id: a.id,
        type: 'attendance',
        date: a.date,
        created_at: a.created_at,
        group_id: a.group_id,
        groups: { name: a.bible_study_groups?.group_name },
        profiles: { name: a.members?.full_name },
        detail: `Attendance recorded`
      })),
      ...(studyData || []).map(s => ({
        id: s.id,
        type: 'study',
        date: s.completion_date,
        created_at: s.created_at,
        group_id: s.group_id,
        groups: { name: s.bible_study_groups?.group_name },
        profiles: { name: null },
        detail: s.study_topic
      }))
    ];

    combined.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    return combined;
  }
};

export const ministryService = {
  getMinistries: async () => {
    const { data, error } = await supabase
      .from("ministries")
      .select("*")
      .order("name");
    if (error) throw error;
    return data;
  },
  createMinistry: async (name) => {
    const { data, error } = await supabase
      .from("ministries")
      .insert([{ name }])
      .select();
    if (error) throw error;
    return data[0];
  },
  deleteMinistry: async (id) => {
    const { error } = await supabase
      .from("ministries")
      .delete()
      .eq("id", id);
    if (error) throw error;
    return true;
  }
};
